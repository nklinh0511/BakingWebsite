package com.example.bakingWebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BakingWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(BakingWebsiteApplication.class, args);
	}

}
