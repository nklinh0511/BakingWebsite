package com.example.bakingWebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BakingWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
